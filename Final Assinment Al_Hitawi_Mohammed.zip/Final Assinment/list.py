''' 
This code preaperd by Mr.A Alwahab and finshing the task by Al-Hitawi Mohammed   neptune_code: P622VN

Create a Python program that captures and displays a person's todo list. Continually prompt the user for another item 
until they enter a blank item. After all the items are entered, display the todo list back to the user.

Sample Output:
Enter a task for your todo list. Press <enter> when done: Buy cat food.
Task added.
Enter a task for your todo list. Press <enter> when done: Mow the lawn.
Task added.
Enter a task for your todo list. Press <enter> when done: Take over the world.
Task added.
Enter a task for your todo list. Press <enter> when done:
Your ToDo List:
Buy cat food.
Mow the lawn.
Take over the world.
'''

#!/usr/bin/env python3
# Create a list to hold the to-do tasks.
to_do_list = []
# initilaze to zero 
finished = False # put the correct word
while not finished:  #not finished   countinues 
    task = input('Enter a task for your to-do list. Press <enter> when done: ')# aske user to input text
    if len(task)== 0:  # if it is a blank stop 
        finished = True  # by changeing value of finished will exits from loop
    else:  # if task has value of lenghth > 0  
       to_do_list.append(task)  # insert this value to  list by using built_in fun append()
    #    print(to_do_list)
       print('Task added.')
# Display the to-do list.
print('Your To-Do List:')
print('-' * 16)
for index in to_do_list:      # itreate for each elments of list and print them 
    print(index,'\n')
