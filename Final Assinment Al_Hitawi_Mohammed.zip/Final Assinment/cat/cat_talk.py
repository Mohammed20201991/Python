'''
This code preaperd by Mr.A Alwahab and finshing the task by Al-Hitawi Mohammed   neptune_code: P622VN
'''
#!/usr/bin/env python3
# import or include module called cat_say= moudel_name 
import cat_say
# build function 
def main():
    # call model name dot function name call 
    cat_say.cat_say('Feed me.')  #fill the balnk
    cat_say.cat_say('Pet me.')    #filll the blank 
    cat_say.cat_say('Purr. Purr.')  #fill the blank
    # let the cat say GoodBye   it can be done in tow ways 
    cat_say.cat_say('GoodBye.')   ## 1
    # print('GoodBye')            ## 2
    
#------------------------------------------------------------------------
if __name__ == '__main__': # If File cat_say __name__ is set to: __main__
    main() # then call main function 
#print("File cat_say __name__ is set to: {}" .format(__name__)) # to check or trace only 
