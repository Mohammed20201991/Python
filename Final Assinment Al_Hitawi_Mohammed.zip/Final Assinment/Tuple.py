'''
This code preaperd by Mr.A Alwahab and finshing the task by Al-Hitawi Mohammed   neptune_code: P622VN

Create a list of airports that includes a series of tuples containing an airport's name and its code.
Loop through the list and utilize tuple assignment. Use one variable to hold the airport name and
another variable to hold the airport code. Display the airport's name and code to the screen.

Sample output:
The code for O’Hare International Airport is ORD.
The code for Los Angeles International Airport is LAX.
The code for Dallas/Fort Worth International Airport is DFW.
The code for Denver International Airport is DEN.
LinuxTrainingAcademy.
'''

#!/usr/bin/env python3
# intilaze list of tuples   [(,) .....]
airports = [
("O’Hare International Airport", 'ORD .'),
# (#fill the tuple to be as in the second line from the sample output ),
('Los Angeles International Airport','LAX .'),
('Dallas/Fort Worth International Airport', 'DFW .'),
('Denver International Airport', 'DEN .')     ]
#put your code line here      We need to loops for iterating the elments one for list the other for tuple 
""" First loop to travers elements of a list"""
for index in airports:
#put your code line here
  print()
  print('The code for ',sep=' ', end='', flush=True) # to concatenate string with other on same line 
  """ Second loop to travers elements of a tuples inside list(Nested loops)"""
  for key in index: # this loop to iterate each elments of tuple 
   print( key + ' is ', sep=' ', end='', flush=True) # display the elements of tuple and puting it on the same line
# after completing trvers on list that contains  tuple print last sentence below
print()
print('LinuxTrainingAcademy.') # print spreate line after finshing loop
