'''
This code preaperd by Mr.A Alwahab and finshing the task by Al-Hitawi Mohammed   neptune_code: P622VN
1-
Create a program that opens file.txt. Read each line of the file and prepend it with a line number.
The contents of files.txt:
This is line one.
This is line two.
Finally, we are on the third and last line of the file.

Sample output:
1: This is line one.
2: This is line two.
3: Finally, we are on the third and last line of the file.
'''

'''
2-
Read the contents of animals.txt and produce a file named animalssorted.txt that is sorted alphabetically.
The contents of animals.txt:
man
bear
pig
cow
duck
horse
dog

After the program is executed the contents of animalssorted.txt should be:
bear
cow
dog
duck
horse
man
pig
LinuxTrainingAcademy
'''
#--------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------
# # 1 

with open('C:/Users/Mohammed/Desktop/Python/Final Assinment/file.txt') as file:   #open the file from absulute or reltive if it beside 
                        # with open('file.txt') as file:     # if relative path
    line_number = 1   # initilaze  counter 
    for line in file:  # itreate each line in file 
        print(" {}: {}".format(line_number, line.strip()))    # print one line with it is number (value of counter) 
        line_number += 1        # increase counter 

#--------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------
# # 2
unsorted_file_name = 'C:/Users/Mohammed/Desktop/Python/Final Assinment/animals.txt'  # Rread from absulute
sorted_file_name = 'C:/Users/Mohammed/Desktop/Python/Final Assinment/animals-sorted.txt'# rread from absulute
# unsorted_file_name = 'animals.txt'       # Read from relative
# sorted_file_name = 'animals-sorted.txt'  # Read from relative
# create list
animals = []
try:
    with open(unsorted_file_name) as animals_file:    #open file for reading contents and make alies for file name with as
        for index in animals_file:      # itreate for each line(line by line) in file 
            animals.append(index)       # insert elment to list 
    animals.sort()      # sorting elemnts of list using built-in function sort()
except:  # if the code above doesnt excute make exeption 
    print('Could not open {}.'.format(unsorted_file_name))
try:    # try to open file for purpose of writing (inserting in file after sort elments of list )
    with open(sorted_file_name, 'w') as animals_sorted_file:  # mode of file w for writng if file does not exist create one  and make alies for file name with as
        for animal in animals: # loop on elmints of sorted list 
            animals_sorted_file.write(animal)    # print elments in file 
        animals_sorted_file.write('LinuxTrainingAcademy')  # after finshing loop print this line 
except: # in case there is problem with code above go to exeption 
    print('Could not open {}.'.format(sorted_file_name))    