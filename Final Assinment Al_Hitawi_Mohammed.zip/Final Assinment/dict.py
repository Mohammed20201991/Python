''' 
This code preaperd by Mr.A Alwahab and finshing the task by Al-Hitawi Mohammed   neptune_code: P622VN

Create a dictionary that contains a list of people and one interesting fact about each of them.
Display each person and their interesting fact to the screen. Next, change a fact about one of
the people. Also add an additional person and corresponding fact. Display the new list of people
and facts. Run the program multiple times and notice if the order changes.


Sample output:
Jeff: Is afraid of clowns.
David: Plays the piano.
Jason: Can fly an airplane.
Jeff: Is afraid of heights.
David: Plays the piano.
Jason: Can fly an airplane.
Jill: Can hula dance.
'''
#!/usr/bin/env python3
def display_facts(facts):    # function defention to create dictonary and print all elments in form key-> value
    """Displays facts"""    
    # iterate for each elements of dic 
    for fact in facts:
        print('{}: {}'.format(fact, facts[fact])) # print one element fact represent key and facts[fact] represnt value for this key
     
    # initilaze dictonary called facts with their keys and values 
facts = {
    'Jason': 'Can fly an airplane.',
    'Jeff': 'Is afraid of clowns.',
    'David': 'Plays the piano.'
} # end of dic


# call the above function with arguments facts that represents dic 
display_facts(facts)
# Modify 'Jeff'  : 'Is afraid of heights.'
# by using the syntex    dictionary_name['key_name']= new_value_name 
facts['Jeff']= 'Is afraid of heights.'

#add 'Jill' : 'Can hula dance.'
# by using the syntex    dictionary_name['key_name']= value_name 
facts['Jill']='Can hula dance.'

#call the above function again after update and modification 
display_facts(facts)

'''
Run the program multiple times and notice if the order changes.
the order matter in dic so no change accour
'''
