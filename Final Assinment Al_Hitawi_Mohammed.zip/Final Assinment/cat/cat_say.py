''' 
This code preaperd by Mr.A Alwahab and finshing the task by Al-Hitawi Mohammed   neptune_code: P622VN
'''
#!/usr/bin/env python3
def cat_say(text):
    """Generate a picture of a cat saying something"""
    text_length = len(text)
    print(' {}'.format('_' * text_length))
    print(' < {} >'.format(text))
    print(' {}'.format('-' * text_length))
    # print(' /\n',sep=' ', end='', flush=True)
    print('\ /\_/\ /')
    print(' ( o.o )')
    print('  > ^ <')

#------------------------------------------------------------------    
def main():
    text = input('What would you like the cat to say? ')
    #invoke the cat say function 
    cat_say(text)
    # print(type(cat_say(text)))

#-------------------------------------------------------------------    
if __name__ == '__main__':
    #invoke the main function
    main()
    #what is the __main__ and __name__ here?
    # it means that File one(cat_say.py) __name__ is set to the : __main__
    # print("File cat_say __name__ is set to: {}" .format(__name__))

